import { ParsedEvent, ReconnectInterval, createParser } from 'eventsource-parser';

export type ChatGPTAgent = "user" | "system";

export interface ChatGPTMessage {
    role: ChatGPTAgent;
    content: string;
}

export interface OpenAIStreamPayload {
    model: string;
    messages: ChatGPTMessage[];
    temperature: number;
    top_p: number;
    frequency_penalty: number;
    presence_penalty: number;
    max_tokens: number;
    stream: boolean;
    n: number;
}

async function delay(ms: number) {
    return new Promise(resolve => setTimeout(resolve, ms));
}

export async function OpenAIStream(payload: OpenAIStreamPayload) {
    const encoder = new TextEncoder();
    const decoder = new TextDecoder();

    let counter = 0;

    async function makeRequest() {
        try {
            const res = await fetch('https://api.openai.com/v1/chat/completions', {
                method: 'POST',
                headers: {
                    Authorization: `Bearer ${process.env.OPENAI_API_KEY}`,
                    'Content-Type': "application/json",
                },
                body: JSON.stringify(payload),
            });
            console.log("Open stream Response is:", res);
            if (res.status === 429) {
                throw new Error("Too Many Requests");
            }
            return res;
        } catch (error) {
            console.error("Error making request:", error);
            throw error;
        }
    }

    async function fetchWithRetries() {
        let retries = 3; // Maximum number of retries
        let delayMs = 1000; // Initial delay in milliseconds
        while (true) {
            try {
                const res = await makeRequest();
                return res;
            } catch (error) {
                if (retries === 0 || error !== "Too Many Requests") {
                    throw error;
                }
                console.log(`Retrying in ${delayMs}ms...`);
                await delay(delayMs);
                retries--;
                delayMs *= 2; // Exponential backoff
            }
        }
    }

    const res = await fetchWithRetries();
    
    if (!res) {
        throw new Error("Response is null");
    }

    const stream = new ReadableStream({
        async start(controller) {
            function onParse(event: ParsedEvent | ReconnectInterval) {
                if (event.type === 'event') {
                    const data = event.data;
                    if (data === '[DONE]') {
                        controller.close();
                        return;
                    }
                    try {
                        const json = JSON.parse(data);
                        console.log('json', json);
                        const text = json.choices[0].delta?.content || "";
                        console.log('text:', text);
                        if (counter < 2 && (text.match(/\n/) || []).length) {
                            // this is a prefix character (i.e., "\n\n"), do nothing
                            return;
                        }
                        const queue = encoder.encode(text);
                        controller.enqueue(queue);
                        counter++;
                    } catch (error) {
                        controller.error(error);
                    }
                }
            }

            const parser = createParser(onParse);

            const reader = res.body?.getReader();
            let decoder = new TextDecoder();
            let done = false;

            if (!reader) {
                throw new Error("ReadableStream is null");
            }

            while (!done) {
                const { value, done: readerDone } = await reader.read();
                done = readerDone;
                const chunk = decoder.decode(value);
                parser.feed(chunk);
            }
        },
    });

    return stream;
}
