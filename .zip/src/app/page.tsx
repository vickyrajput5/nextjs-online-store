import Image from "next/image";

export default function Home() {
  return (
  <main className="absolute inset-0 flex justify-center items-center">website content</main>
  );
}
